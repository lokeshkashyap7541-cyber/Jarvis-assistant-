package com.jarvis.assistant

/**
 * Turns raw spoken text into a structured Command using simple
 * keyword matching -- no AI API, fully offline.
 *
 * Add new phrases to the `when` block below to extend what Jarvis understands.
 */
sealed class Command {
    data class OpenApp(val appName: String) : Command()
    object OpenSettings : Command()
    object OpenWifiSettings : Command()
    object OpenBluetoothSettings : Command()
    object ToggleFlashlight : Command()
    data class Call(val name: String) : Command()
    data class SendSms(val name: String, val message: String) : Command()
    object WhatTime : Command()
    object BatteryStatus : Command()
    object TakePhoto : Command()
    data class WebSearch(val query: String) : Command()
    object Unknown : Command()
}

object CommandProcessor {

    fun process(rawText: String): Command {
        val text = rawText.lowercase().trim()

        // "open <app>" / "launch <app>" / "start <app>"
        val openPatterns = listOf("open ", "launch ", "start ")
        for (p in openPatterns) {
            if (text.startsWith(p)) {
                val appName = text.removePrefix(p).trim()
                return routeOpen(appName)
            }
        }

        if (text.contains("flashlight") || text.contains("torch")) {
            return Command.ToggleFlashlight
        }

        if (text.contains("wifi") || text.contains("wi-fi")) {
            return Command.OpenWifiSettings
        }

        if (text.contains("bluetooth")) {
            return Command.OpenBluetoothSettings
        }

        if (text.startsWith("call ")) {
            return Command.Call(text.removePrefix("call ").trim())
        }

        if (text.startsWith("text ") || text.startsWith("message ")) {
            // "text mom saying I'm on my way"
            val body = text.removePrefix("text ").removePrefix("message ")
            val parts = body.split(" saying ", " that ")
            return if (parts.size >= 2) {
                Command.SendSms(parts[0].trim(), parts[1].trim())
            } else {
                Command.SendSms(body.trim(), "")
            }
        }

        if (text.contains("what time") || text.contains("current time")) {
            return Command.WhatTime
        }

        if (text.contains("battery")) {
            return Command.BatteryStatus
        }

        if (text.contains("take a photo") || text.contains("take a picture") || text.contains("open camera")) {
            return Command.TakePhoto
        }

        if (text.startsWith("search for ") || text.startsWith("search ") || text.startsWith("google ")) {
            val q = text.removePrefix("search for ").removePrefix("search ").removePrefix("google ")
            return Command.WebSearch(q.trim())
        }

        if (text.contains("settings")) {
            return Command.OpenSettings
        }

        // ---- No exact rule matched: fall back to the on-device AI similarity classifier ----
        val classified = IntentClassifier.classify(text)
        if (classified != null) {
            val (intent, _) = classified
            val entity = IntentClassifier.extractEntity(text)
            return when (intent) {
                "OPEN_APP" -> if (entity.isNotBlank()) routeOpen(entity) else Command.Unknown
                "FLASHLIGHT" -> Command.ToggleFlashlight
                "WIFI" -> Command.OpenWifiSettings
                "BLUETOOTH" -> Command.OpenBluetoothSettings
                "SETTINGS" -> Command.OpenSettings
                "CALL" -> if (entity.isNotBlank()) Command.Call(entity) else Command.Unknown
                "SMS" -> if (entity.isNotBlank()) Command.SendSms(entity, "") else Command.Unknown
                "TIME" -> Command.WhatTime
                "BATTERY" -> Command.BatteryStatus
                "CAMERA" -> Command.TakePhoto
                "SEARCH" -> if (entity.isNotBlank()) Command.WebSearch(entity) else Command.Unknown
                else -> Command.Unknown
            }
        }

        return Command.Unknown
    }

    private fun routeOpen(appName: String): Command {
        return when {
            appName.contains("wifi") || appName.contains("wi-fi") -> Command.OpenWifiSettings
            appName.contains("bluetooth") -> Command.OpenBluetoothSettings
            appName.contains("setting") -> Command.OpenSettings
            appName.contains("camera") -> Command.TakePhoto
            else -> Command.OpenApp(appName)
        }
    }
}
