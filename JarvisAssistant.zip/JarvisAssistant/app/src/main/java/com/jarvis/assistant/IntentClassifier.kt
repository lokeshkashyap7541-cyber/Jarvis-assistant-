package com.jarvis.assistant

/**
 * A lightweight ON-DEVICE "AI" layer for understanding loosely-phrased commands.
 *
 * This is NOT a neural network / LLM and needs no API key, no internet, and no
 * model download -- everything below runs instantly on-device. It works by
 * comparing what you said against small sets of example phrases per intent
 * using token (word) similarity, so Jarvis understands variations it was
 * never explicitly coded for -- e.g. "fire up the camera", "it's dark, turn
 * on the light", "how much juice is left" -- not just exact keywords.
 *
 * This is the same basic idea real assistants used before cloud NLU: a
 * bag-of-words similarity classifier. It's simple, fast, fully private
 * (nothing leaves the phone), and easy to extend by adding more example
 * phrases below.
 */
object IntentClassifier {

    // Each intent is "trained" on a handful of natural phrasings.
    // Add more examples any time to make Jarvis understand more ways of saying the same thing.
    private val intentExamples: Map<String, List<String>> = mapOf(
        "OPEN_APP" to listOf(
            "open the app", "launch app", "start app", "fire up app",
            "can you open", "i want to use", "switch to app", "go to app", "bring up app"
        ),
        "FLASHLIGHT" to listOf(
            "turn on the flashlight", "turn off the torch", "switch on the light",
            "i need light", "its dark turn on the light", "shine a light"
        ),
        "WIFI" to listOf(
            "turn on wifi", "connect to wifi", "open wireless settings", "check wifi", "wireless network"
        ),
        "BLUETOOTH" to listOf(
            "turn on bluetooth", "connect bluetooth", "pair a device", "bluetooth settings"
        ),
        "SETTINGS" to listOf(
            "open settings", "go to settings", "show system settings", "phone settings"
        ),
        "CALL" to listOf(
            "call someone", "dial a number", "phone someone", "give a call to", "ring someone up"
        ),
        "SMS" to listOf(
            "send a text", "message someone", "text someone saying", "drop a text"
        ),
        "TIME" to listOf(
            "what time is it", "tell me the time", "current time please", "clock"
        ),
        "BATTERY" to listOf(
            "how much battery", "check battery level", "battery percentage", "how much juice is left", "power remaining"
        ),
        "CAMERA" to listOf(
            "open camera", "take a photo", "take a picture", "click a picture", "capture a photo", "snap a pic"
        ),
        "SEARCH" to listOf(
            "search the web", "google something", "look up something", "find information about", "search online for"
        )
    )

    private val stopWords = setOf(
        "the", "a", "an", "to", "is", "please", "can", "you", "me", "i", "my",
        "for", "it", "up", "on", "off", "of", "at", "in"
    )

    // Words that signal WHAT the user wants but aren't part of the entity name
    // (e.g. app name, contact name). Stripped out during entity extraction.
    private val triggerWords = setOf(
        "open", "launch", "start", "fire", "app", "can", "you", "i", "want", "to", "use",
        "switch", "go", "bring", "call", "someone", "dial", "phone", "ring", "give", "a",
        "text", "message", "send", "drop", "saying", "that", "search", "for", "google",
        "look", "find", "information", "about", "online", "please"
    )

    /** Returns the best-matching intent label and confidence score (0.0-1.0), or null if nothing scores high enough. */
    fun classify(text: String): Pair<String, Double>? {
        val inputTokens = tokenize(text)
        if (inputTokens.isEmpty()) return null

        var bestIntent: String? = null
        var bestScore = 0.0

        for ((intent, examples) in intentExamples) {
            for (example in examples) {
                val score = jaccardSimilarity(inputTokens, tokenize(example))
                if (score > bestScore) {
                    bestScore = score
                    bestIntent = intent
                }
            }
        }

        return if (bestIntent != null && bestScore >= 0.15) bestIntent to bestScore else null
    }

    /** Strips trigger/stop words to guess the "entity" in a sentence -- e.g. an app or contact name. */
    fun extractEntity(text: String): String {
        return text.lowercase()
            .replace(Regex("[^a-z0-9 ]"), "")
            .split(" ")
            .filter { it.isNotBlank() && it !in triggerWords }
            .joinToString(" ")
            .trim()
    }

    private fun tokenize(text: String): Set<String> =
        text.lowercase()
            .replace(Regex("[^a-z0-9 ]"), "")
            .split(" ")
            .filter { it.isNotBlank() && it !in stopWords }
            .toSet()

    private fun jaccardSimilarity(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val intersection = a.intersect(b).size.toDouble()
        val union = a.union(b).size.toDouble()
        return intersection / union
    }
}
