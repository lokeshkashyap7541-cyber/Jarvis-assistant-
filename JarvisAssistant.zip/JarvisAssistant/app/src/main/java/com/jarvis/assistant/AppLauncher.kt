package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.app.SearchManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.*

/**
 * Executes Commands against real Android system APIs.
 */
class AppLauncher(private val context: Context) {

    private var flashlightOn = false

    /** Returns a human-readable result to speak back / show in the log. */
    fun execute(command: Command): String {
        return when (command) {
            is Command.OpenApp -> openAppByName(command.appName)
            is Command.OpenSettings -> openSettings()
            is Command.OpenWifiSettings -> openIntent(Settings.ACTION_WIFI_SETTINGS, "Opening Wi-Fi settings")
            is Command.OpenBluetoothSettings -> openIntent(Settings.ACTION_BLUETOOTH_SETTINGS, "Opening Bluetooth settings")
            is Command.ToggleFlashlight -> toggleFlashlight()
            is Command.Call -> callContact(command.name)
            is Command.SendSms -> sendSms(command.name, command.message)
            is Command.WhatTime -> "It's ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}"
            is Command.BatteryStatus -> batteryStatus()
            is Command.TakePhoto -> openIntent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE, "Opening camera")
            is Command.WebSearch -> webSearch(command.query)
            is Command.Unknown -> "Sorry, I didn't understand that command."
        }
    }

    // ---- App launching by spoken name (fuzzy match against installed apps) ----

    private fun openAppByName(spokenName: String): String {
        val pm = context.packageManager
        val installedApps: List<ApplicationInfo> = pm.getInstalledApplications(0)

        val target = spokenName.lowercase().replace(" ", "")

        // 1) exact label match, 2) label contains spoken name, 3) spoken name contains label
        var match = installedApps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().replace(" ", "") == target
        }
        if (match == null) {
            match = installedApps.firstOrNull {
                pm.getApplicationLabel(it).toString().lowercase().replace(" ", "").contains(target)
            }
        }
        if (match == null) {
            match = installedApps.firstOrNull {
                target.contains(pm.getApplicationLabel(it).toString().lowercase().replace(" ", ""))
            }
        }

        return if (match != null) {
            val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                "Opening ${pm.getApplicationLabel(match).toString()}"
            } else {
                "Found $spokenName but it can't be launched directly."
            }
        } else {
            "I couldn't find an app called $spokenName on this phone."
        }
    }

    // ---- System settings screens ----

    private fun openSettings(): String = openIntent(Settings.ACTION_SETTINGS, "Opening settings")

    private fun openIntent(action: String, spokenReply: String): String {
        return try {
            val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            spokenReply
        } catch (e: Exception) {
            "Couldn't open that: ${e.message}"
        }
    }

    // ---- Flashlight (works directly, no settings screen needed) ----

    private fun toggleFlashlight(): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (camId == null) return "This device has no flashlight."
            flashlightOn = !flashlightOn
            cameraManager.setTorchMode(camId, flashlightOn)
            if (flashlightOn) "Flashlight on" else "Flashlight off"
        } catch (e: Exception) {
            "Couldn't control the flashlight: ${e.message}"
        }
    }

    // ---- Calling / SMS (dialer / messaging app opened with details pre-filled;
    //      this avoids needing the sensitive CALL_PHONE/SEND_SMS runtime permission
    //      to actually place the call/text automatically) ----

    private fun callContact(name: String): String {
        val number = ContactsHelper.findNumberByName(context, name)
        return if (number != null) {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            "Calling $name"
        } else {
            "I couldn't find $name in your contacts."
        }
    }

    private fun sendSms(name: String, message: String): String {
        val number = ContactsHelper.findNumberByName(context, name)
        return if (number != null) {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Opening a text to $name"
        } else {
            "I couldn't find $name in your contacts."
        }
    }

    // ---- Battery ----

    private fun batteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery is at $level percent"
    }

    // ---- Web search fallback ----

    private fun webSearch(query: String): String {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Searching for $query"
        } catch (e: Exception) {
            "Couldn't search: ${e.message}"
        }
    }
}
