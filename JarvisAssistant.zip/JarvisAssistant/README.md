# Jarvis — Offline Voice Assistant (Android)

A real Android app (Kotlin) that listens for voice commands and acts on them
directly on your phone — opening apps, toggling the flashlight, jumping to
Wi-Fi/Bluetooth/Settings screens, calling or texting a contact, checking
battery, and more. No cloud AI API and no internet needed — command
understanding is done entirely on-device, first with keyword rules, then
with a lightweight similarity-based "AI" fallback (`IntentClassifier.kt`)
that understands looser phrasing like "fire up the camera" or "how much
juice is left" without you having to say the exact trigger word.

## ⚠️ About the .apk file

I can't compile a ready-to-install `.apk` for you directly — building one
needs the Android SDK and Gradle downloading dependencies from the internet,
which isn't available in this chat environment. But turning this project
into an installable APK on your own machine takes about 2 minutes once
Android Studio is open. See "Get the installable APK" below.

## ⚠️ Important — how to run this

This is a **native Android Studio project**, not something that runs in a
browser. You cannot preview it here. To use it:

1. Install **Android Studio** (free): https://developer.android.com/studio
2. `File → Open` and select the `JarvisAssistant` folder
3. Let Gradle sync (first sync downloads dependencies — needs internet)
4. Connect your phone via USB with **Developer Options → USB debugging** on,
   or use an emulator
5. Click ▶ Run

On first launch, grant the microphone, contacts, and camera permission
prompts — without them, voice input and some commands won't work.

## What it can do out of the box

| Say this | It does this |
|---|---|
| "open camera" / "take a photo" | Launches the camera app |
| "open whatsapp" / "open spotify" / "open \<any installed app>" | Fuzzy-matches installed app names and launches it |
| "open settings" | Opens system Settings |
| "wifi" / "open wifi settings" | Opens Wi-Fi settings screen |
| "bluetooth" | Opens Bluetooth settings screen |
| "flashlight" / "torch" | Toggles the flashlight on/off directly |
| "call mom" | Opens the dialer pre-filled with mom's number from Contacts |
| "text mom saying I'm on my way" | Opens Messages pre-filled to mom with that text |
| "what time is it" | Speaks the current time |
| "battery" | Speaks battery percentage |
| "search for iphone 17 price" | Opens a web search |

Jarvis replies out loud (text-to-speech) and logs the conversation on screen.

## Why calls/texts open an app instead of sending directly

Actually placing a call or firing an SMS with no user interaction requires
the `CALL_PHONE` / `SEND_SMS` **runtime permissions**, which Google treats
as highly sensitive (apps requesting them get extra Play Store scrutiny).
This build opens the dialer/messaging app pre-filled instead, so you just
tap send — safer, and no special Play Store review needed. If you want true
one-shot calling for personal/sideloaded use, see the note in
`AppLauncher.kt` — swap `ACTION_DIAL` for `ACTION_CALL` and add the
`CALL_PHONE` permission request.

## Get the installable APK

1. Open the project in Android Studio (see steps above) and let Gradle sync
2. Menu: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
3. When it finishes, click the **"locate"** link in the notification popup
   (or find it at `app/build/outputs/apk/debug/app-debug.apk`)
4. Copy that `.apk` file to your phone (USB, email it to yourself, Google
   Drive, etc.) and tap it on your phone to install — you'll need to allow
   "install from unknown sources" for your file manager the first time
5. Done — no Play Store needed

## Project structure

```
app/src/main/java/com/jarvis/assistant/
├── MainActivity.kt       — mic button, speech-to-text, TTS, permissions, UI log
├── CommandProcessor.kt   — keyword rules, then falls back to IntentClassifier
├── IntentClassifier.kt   — on-device "AI": similarity-based intent matching, no API
├── AppLauncher.kt        — executes a Command using real Android system APIs
└── ContactsHelper.kt     — looks up a phone number by contact name
app/src/main/res/layout/activity_main.xml — the UI (dark theme, mic button, log)
app/src/main/AndroidManifest.xml          — permissions + app entry point
```

## How the on-device "AI" works

`IntentClassifier.kt` holds a handful of example phrases per intent (e.g.
FLASHLIGHT: "turn on the flashlight", "it's dark turn on the light"...). When
you say something, it's compared against every example using **Jaccard
similarity** (word-overlap between your sentence and each example) — the
highest-scoring intent above a confidence threshold wins. This is genuinely
useful and 100% private (nothing leaves the phone, no API key, no model
download), but it's worth being clear it's a similarity classifier, not a
neural network — it won't handle complex multi-step reasoning the way a
cloud LLM would. To extend it, just add more example phrases to the relevant
intent in `intentExamples`.

## Extending it — adding a new voice command

1. Add a new case to the `Command` sealed class in `CommandProcessor.kt`
2. Add a keyword match for it in `CommandProcessor.process()`
3. Handle it in `AppLauncher.execute()` with the real Android API call

Example — add "open camera in selfie mode":
```kotlin
// CommandProcessor.kt
if (text.contains("selfie")) return Command.TakeSelfie

// AppLauncher.kt
is Command.TakeSelfie -> {
    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
        putExtra("android.intent.extras.CAMERA_FACING", 1) // front camera
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(intent)
    "Say cheese"
}
```

## Known limitations (be upfront about these)

- **App-drawer visibility on Android 11+**: some apps can hide themselves
  from `QUERY_ALL_PACKAGES` results depending on manifest declarations —
  rare, but if an app won't open by name, it's likely this.
- **Flashlight** requires a rear camera with flash; devices without one
  will get a spoken "no flashlight" reply.
- **Wi-Fi/Bluetooth toggling**: since Android 10, apps can no longer flip
  Wi-Fi/Bluetooth on/off directly for privacy reasons — this app opens the
  settings screen instead, which is the standard workaround every assistant
  app uses today.
- **No wake word ("Hey Jarvis")** yet — you tap the mic button to start
  listening. Adding always-on wake-word detection needs a background
  foreground-service + an on-device wake-word engine (e.g. Porcupine) and
  battery-usage trade-offs, which is a good next step once this base works.
